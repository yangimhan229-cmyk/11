package com.tradron.httpvideodownloader;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Small, dependency-free parser for standard HLS master and MPEG-TS media playlists. */
public final class HlsParser {
    private HlsParser() {}

    public static final class Variant {
        public final String label;
        public final String url;
        public Variant(String label, String url) { this.label = label; this.url = url; }
    }
    public static final class Media {
        public final List<String> segments = new ArrayList<>();
        public boolean encrypted;
        public boolean byteRange;
        public boolean fmp4;
        public boolean isPlaylist;
        public boolean isMaster;
    }

    public static String absolute(String base, String path) {
        try { return URI.create(base).resolve(path.trim()).toString(); }
        catch (RuntimeException e) { throw new IllegalArgumentException("잘못된 HLS 경로: " + path, e); }
    }

    public static List<Variant> parseVariants(String text, String manifestUrl) {
        ArrayList<Variant> result = new ArrayList<>();
        String[] lines = text.replace("\r", "").split("\n");
        String attributes = null;
        for (String line : lines) {
            line = line.trim();
            if (line.startsWith("#EXT-X-STREAM-INF:")) {
                attributes = line.substring("#EXT-X-STREAM-INF:".length());
            } else if (attributes != null && !line.isEmpty() && !line.startsWith("#")) {
                String resolution = attribute(attributes, "RESOLUTION");
                String bandwidth = attribute(attributes, "BANDWIDTH");
                String label;
                if (resolution != null && resolution.contains("x")) {
                    String[] wh = resolution.split("x");
                    label = wh.length == 2 ? wh[1] + "p (" + resolution + ")" : resolution;
                } else if (bandwidth != null) {
                    try { label = String.format(Locale.US, "%.1f Mbps", Long.parseLong(bandwidth) / 1_000_000.0); }
                    catch (NumberFormatException e) { label = bandwidth + " bps"; }
                } else label = "HLS 원본";
                result.add(new Variant(label, absolute(manifestUrl, line)));
                attributes = null;
            }
        }
        return result;
    }

    private static String attribute(String s, String key) {
        Matcher matcher = Pattern.compile("(?:^|,)" + key + "=([^,]+)", Pattern.CASE_INSENSITIVE).matcher(s);
        return matcher.find() ? matcher.group(1).replace("\"", "").trim() : null;
    }

    public static Media parseMedia(String text, String playlistUrl) {
        Media out = new Media();
        String[] lines = text.replace("\r", "").split("\n");
        for (String line : lines) {
            line = line.trim();
            if (line.equals("#EXTM3U")) out.isPlaylist = true;
            if (line.startsWith("#EXT-X-STREAM-INF:")) out.isMaster = true;
            if (line.startsWith("#EXT-X-KEY:") && !line.contains("METHOD=NONE")) out.encrypted = true;
            if (line.startsWith("#EXT-X-BYTERANGE:")) out.byteRange = true;
            if (line.startsWith("#EXT-X-MAP:")) out.fmp4 = true;
            if (!line.isEmpty() && !line.startsWith("#")) out.segments.add(absolute(playlistUrl, line));
        }
        return out;
    }
}
