package com.tradron.httpvideodownloader;

import android.webkit.CookieManager;
import android.webkit.WebView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Sends normal requests with the active in-app WebView user agent and eligible cookies.
 * Does not attempt to bypass CAPTCHA, server access controls, or DRM. */
public class NetworkClient {
    public static final class HttpFailure extends IOException {
        public final int code;
        public final String stage;
        public final String host;
        public HttpFailure(int code, String stage, String host) {
            super(stage + " 요청 실패 · HTTP " + code + " · " + host);
            this.code = code; this.stage = stage; this.host = host;
        }
    }

    private final String userAgent;
    private final String pageUrl;

    public NetworkClient(WebView webView, String pageUrl) {
        this.userAgent = webView.getSettings().getUserAgentString();
        this.pageUrl = pageUrl;
    }

    public HttpURLConnection open(String url, String stage) throws IOException {
        String current = url;
        for (int hop = 0; hop < 6; hop++) {
            if (!current.startsWith("https://") && !current.startsWith("http://"))
                throw new IOException("HTTP/HTTPS 주소만 지원합니다.");
            HttpURLConnection connection = (HttpURLConnection) new URL(current).openConnection();
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            // Handle redirects ourselves to apply the correct cookies for each host.
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("User-Agent", userAgent);
            connection.setRequestProperty("Accept", "*/*");
            if (pageUrl.startsWith("http://") || pageUrl.startsWith("https://"))
                connection.setRequestProperty("Referer", pageUrl);
            String cookie = CookieManager.getInstance().getCookie(current);
            if (cookie != null && !cookie.isEmpty())
                connection.setRequestProperty("Cookie", cookie);
            int status = connection.getResponseCode();
            if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
                String location = connection.getHeaderField("Location");
                if (location == null || location.isEmpty()) {
                    connection.disconnect();
                    throw new IOException(stage + " 요청이 리다이렉트되었지만 Location이 없습니다.");
                }
                // Do not log signed redirect URLs or cookies.
                try { current = URI.create(current).resolve(location).toString(); }
                catch (RuntimeException e) { throw new IOException("잘못된 리다이렉트 주소", e); }
                connection.disconnect();
                continue;
            }
            if (status < 200 || status >= 300) {
                String host;
                try { host = URI.create(current).getHost(); }
                catch (RuntimeException e) { host = "unknown"; }
                connection.disconnect();
                throw new HttpFailure(status, stage, host);
            }
            return connection;
        }
        throw new IOException(stage + " 요청이 리다이렉트 횟수(6회)를 초과했습니다.");
    }

    public String getText(String url, String stage) throws IOException {
        HttpURLConnection connection = open(url, stage);
        try (InputStream in = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16384];
            int n;
            while ((n = in.read(buffer)) != -1) {
                out.write(buffer, 0, n);
                if (out.size() > 3_000_000) throw new IOException(stage + " 응답이 너무 큽니다.");
            }
            return out.toString(StandardCharsets.UTF_8.name());
        } finally { connection.disconnect(); }
    }

    public long copy(String url, String stage, OutputStream out) throws IOException {
        HttpURLConnection connection = open(url, stage);
        try (InputStream in = connection.getInputStream()) {
            byte[] buffer = new byte[64 * 1024];
            int n; long count = 0;
            while ((n = in.read(buffer)) != -1) {
                out.write(buffer, 0, n);
                count += n;
            }
            return count;
        } finally { connection.disconnect(); }
    }
}
