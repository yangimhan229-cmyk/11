package com.tradron.httpvideodownloader;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONTokener;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** HTTP Video Downloader 1.0.9
 * Opens a page in an in-app WebView, captures public media URLs, and reuses the
 * *in-app* cookie/session for manifest and segment requests. No Cloudflare or
 * site access-control bypass is implemented. Only download media you may save. */
public final class MainActivity extends Activity {
    private static final int CREATE_DOCUMENT = 1291;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Set<String> mediaCandidates = Collections.synchronizedSet(new HashSet<>());
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private final List<Quality> qualities = new ArrayList<>();

    private EditText urlInput;
    private WebView webView;
    private Spinner qualitySpinner;
    private Button browseButton, analyzeButton, downloadButton;
    private TextView status;
    private String pageUrl = "";
    private boolean analysisRequested;

    static final class Quality {
        final String title;
        final String url;
        final boolean hls;
        Quality(String title, String url, boolean hls) {
            this.title = title; this.url = url; this.hls = hls;
        }
        @Override public String toString() { return title; }
    }

    private int dp(float px) { return (int) (px * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12), dp(12), dp(12), dp(8));
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("HTTP Video Downloader 1.0.9");
        title.setTextSize(20);
        title.setPadding(0, 0, 0, dp(8));
        root.addView(title);

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
                android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setHint("https://영상페이지주소");
        root.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(48)));

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(buttons);
        browseButton = new Button(this);
        browseButton.setText("사이트 열기");
        buttons.addView(browseButton, new LinearLayout.LayoutParams(0, dp(54), 1));
        analyzeButton = new Button(this);
        analyzeButton.setText("화질조회");
        buttons.addView(analyzeButton, new LinearLayout.LayoutParams(0, dp(54), 1));

        qualitySpinner = new Spinner(this);
        root.addView(qualitySpinner, new LinearLayout.LayoutParams(-1, dp(49)));
        updateQualityList();

        downloadButton = new Button(this);
        downloadButton.setText("선택한 화질 다운로드");
        downloadButton.setEnabled(false);
        root.addView(downloadButton, new LinearLayout.LayoutParams(-1, dp(50)));

        ScrollView scrollView = new ScrollView(this);
        root.addView(scrollView, new LinearLayout.LayoutParams(-1, dp(82)));
        status = new TextView(this);
        status.setTextSize(13);
        status.setTextIsSelectable(true);
        scrollView.addView(status);
        showStatus("① 사이트 열기 → ② 영상 재생 → ③ 화질조회 → ④ 다운로드");

        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1f));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (analysisRequested) {
                    showStatus("페이지 로딩 완료. 영상의 재생 버튼을 누른 뒤 화질을 조회합니다.");
                    handler.postDelayed(() -> scanDomAndAnalyze(false), 2800);
                }
            }
            @Override public void onLoadResource(WebView view, String url) {
                capture(url);
            }
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view,
                                                                                       WebResourceRequest request) {
                if (request != null) capture(request.getUrl().toString());
                return null;
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request,
                    android.webkit.WebResourceResponse errorResponse) {
                if (request != null && request.isForMainFrame()) {
                    runOnUiThread(() -> showStatus("영상 페이지 접속에서 HTTP " +
                            errorResponse.getStatusCode() + " 발생. 앱 내 로그인/접근 가능 여부를 확인하세요."));
                }
            }
        });

        browseButton.setOnClickListener(v -> openPage(false));
        analyzeButton.setOnClickListener(v -> {
            analysisRequested = true;
            String target = urlInput.getText().toString().trim();
            if (!validUrl(target)) { showStatus("HTTP/HTTPS 영상 페이지 주소를 입력하세요."); return; }
            if (webView.getUrl() == null || !target.equals(pageUrl)) openPage(true);
            else scanDomAndAnalyze(true);
        });
        downloadButton.setOnClickListener(v -> chooseFile());
    }

    private static boolean validUrl(String url) {
        try {
            URI parsed = new URI(url);
            return ("https".equalsIgnoreCase(parsed.getScheme()) ||
                    "http".equalsIgnoreCase(parsed.getScheme())) && parsed.getHost() != null;
        } catch (Exception e) { return false; }
    }

    private void openPage(boolean analyze) {
        String target = urlInput.getText().toString().trim();
        if (!validUrl(target)) { showStatus("올바른 HTTP/HTTPS 영상 페이지 URL을 입력하세요."); return; }
        pageUrl = target;
        analysisRequested = analyze;
        mediaCandidates.clear();
        qualities.clear();
        updateQualityList();
        showStatus("앱 내부 브라우저에서 열고 있습니다. Chrome 로그인 정보는 자동 공유되지 않습니다.");
        webView.loadUrl(target);
    }

    /** Captures URLs observed through the WebView. Does not intercept or modify responses. */
    private void capture(String url) {
        if (url == null || url.length() > 4096) return;
        String lower = url.toLowerCase(Locale.ROOT);
        if ((lower.contains(".m3u8") || lower.contains(".mp4") ||
                lower.contains(".m4v") || lower.contains(".webm")) && validUrl(url)) {
            mediaCandidates.add(url);
        }
    }

    private static final String DISCOVER_JS =
            "(function(){try{let found=[];function add(v){if(typeof v==='string'&&" +
            "/https?:\\/\\//i.test(v)&&/\\.(m3u8|mp4|m4v|webm)([?#]|$)/i.test(v))found.push(v)}" +
            "document.querySelectorAll('video,source').forEach(e=>{add(e.src);add(e.currentSrc);add(e.getAttribute('src'))});" +
            "performance.getEntriesByType('resource').forEach(e=>add(e.name));" +
            "document.querySelectorAll('script').forEach(e=>{let s=(e.textContent||'').slice(0,120000);" +
            "let r=/https?:\\/\\/[^\\s\\\"'<>]+?\\.(?:m3u8|mp4|m4v|webm)(?:\\?[^\\s\\\"'<>]*)?/gi;" +
            "let m;while((m=r.exec(s))!==null&&found.length<150)add(m[0].replace(/\\\\\\//g,'/'))});" +
            "return JSON.stringify([...new Set(found)].slice(0,150));" +
            "}catch(e){return '[]'}})()";

    private void scanDomAndAnalyze(boolean immediate) {
        if (!analysisRequested) return;
        if (immediate) showStatus("WebView의 미디어 요청과 영상 태그를 확인 중입니다.");
        webView.evaluateJavascript(DISCOVER_JS, result -> {
            try {
                Object raw = new JSONTokener(result).nextValue();
                JSONArray list = new JSONArray(String.valueOf(raw));
                for (int i = 0; i < list.length(); i++) capture(list.optString(i));
            } catch (Exception ignored) { }
            if (mediaCandidates.isEmpty()) {
                showStatus("영상 주소가 아직 발견되지 않았습니다. 아래 브라우저에서 영상을 재생한 다음 화질조회를 다시 누르세요.");
                return;
            }
            queryQualityCandidates();
        });
    }

    private void queryQualityCandidates() {
        if (!busy.compareAndSet(false, true)) { showStatus("이미 분석 중입니다."); return; }
        showStatus("발견한 영상 URL " + mediaCandidates.size() + "개에서 화질 목록 분석 중...");
        List<String> candidates;
        synchronized (mediaCandidates) { candidates = new ArrayList<>(mediaCandidates); }
        // Prefer HLS playlists because they may advertise multiple qualities.
        candidates.sort((a, b) -> Boolean.compare(b.toLowerCase(Locale.ROOT).contains(".m3u8"),
                a.toLowerCase(Locale.ROOT).contains(".m3u8")));
        final NetworkClient net = new NetworkClient(webView, pageUrl);
        worker.execute(() -> {
            List<Quality> found = new ArrayList<>();
            List<String> failures = new ArrayList<>();
            int checked = 0;
            for (String url : candidates) {
                if (++checked > 20 || found.size() >= 30) break;
                boolean hls = url.toLowerCase(Locale.ROOT).contains(".m3u8");
                if (!hls) {
                    found.add(new Quality("MP4/원본 파일", url, false));
                    continue;
                }
                try {
                    String m3u8 = net.getText(url, "M3U8 화질 목록");
                    if (!m3u8.startsWith("#EXTM3U")) {
                        failures.add("M3U8이 아닌 응답을 받았습니다.");
                        continue;
                    }
                    List<HlsParser.Variant> variants = HlsParser.parseVariants(m3u8, url);
                    if (variants.isEmpty()) found.add(new Quality("HLS 원본(.ts)", url, true));
                    else for (HlsParser.Variant variant : variants)
                        found.add(new Quality("HLS " + variant.label + " (.ts)", variant.url, true));
                } catch (IOException e) { failures.add(e.getMessage()); }
            }
            runOnUiThread(() -> {
                busy.set(false);
                qualities.clear();
                qualities.addAll(found);
                updateQualityList();
                if (found.isEmpty()) {
                    showStatus("화질조회 실패. " + (failures.isEmpty() ?
                            "재생 버튼을 눌러 영상 주소가 나타나는지 확인하세요." :
                            failures.get(0) + "\n" +
                            "앱 내 WebView의 쿠키/접근 권한이 Chrome과 다를 수 있으며, " +
                            "서버가 직접 요청을 제한하는 경우 앱에서 강제로 해제할 수 없습니다."));
                } else {
                    showStatus("화질 " + found.size() + "개를 찾았습니다. 화질 선택 후 저장 위치를 지정하세요." +
                            (failures.isEmpty() ? "" : "\n일부 주소 요청 실패: " + failures.get(0)));
                }
            });
        });
    }

    private void updateQualityList() {
        List<String> labels = new ArrayList<>();
        if (qualities.isEmpty()) labels.add("조회된 화질 없음");
        else for (Quality quality : qualities) labels.add(quality.title);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        qualitySpinner.setAdapter(adapter);
        if (downloadButton != null) downloadButton.setEnabled(!qualities.isEmpty());
    }

    private void chooseFile() {
        if (qualities.isEmpty() || busy.get()) return;
        Quality selected = qualities.get(qualitySpinner.getSelectedItemPosition());
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(selected.hls ? "video/mp2t" : "video/mp4");
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        intent.putExtra(Intent.EXTRA_TITLE, "video_" + timestamp + (selected.hls ? ".ts" : ".mp4"));
        startActivityForResult(intent, CREATE_DOCUMENT);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (requestCode != CREATE_DOCUMENT || resultCode != RESULT_OK ||
                intent == null || intent.getData() == null || qualities.isEmpty()) return;
        Uri destination = intent.getData();
        int selectedIndex = qualitySpinner.getSelectedItemPosition();
        if (selectedIndex < 0 || selectedIndex >= qualities.size()) return;
        Quality selected = qualities.get(selectedIndex);
        if (!busy.compareAndSet(false, true)) return;
        downloadButton.setEnabled(false);
        showStatus("다운로드 시작. 저장 중에는 앱 화면을 유지해 주세요.");
        NetworkClient net = new NetworkClient(webView, pageUrl);
        worker.execute(() -> {
            try (OutputStream out = getContentResolver().openOutputStream(destination, "w")) {
                if (out == null) throw new IOException("저장 파일을 열 수 없습니다.");
                if (!selected.hls) {
                    net.copy(selected.url, "원본 영상 다운로드", out);
                } else {
                    String text = net.getText(selected.url, "선택 화질 M3U8");
                    HlsParser.Media media = HlsParser.parseMedia(text, selected.url);
                    if (!media.isPlaylist) throw new IOException("유효한 HLS 재생목록이 아닙니다.");
                    if (media.isMaster) throw new IOException("미디어 재생목록이 아닌 마스터 목록입니다.");
                    if (media.encrypted) throw new IOException("암호화된 HLS는 지원하지 않습니다.");
                    if (media.byteRange || media.fmp4)
                        throw new IOException("BYTERANGE/fMP4 세그먼트는 .ts 결합을 지원하지 않습니다.");
                    if (media.segments.isEmpty()) throw new IOException("영상 세그먼트를 찾지 못했습니다.");
                    int total = media.segments.size();
                    for (int i = 0; i < total; i++) {
                        net.copy(media.segments.get(i), "HLS 세그먼트 " + (i + 1) + "/" + total, out);
                        int progress = i + 1;
                        if (progress == total || progress % 5 == 0)
                            runOnUiThread(() -> showStatus("HLS 저장 중: " + progress + "/" + total));
                    }
                }
                out.flush();
                runOnUiThread(() -> showStatus("완료: 선택한 폴더에 저장했습니다."));
            } catch (Exception e) {
                runOnUiThread(() -> showStatus("다운로드 실패: " + e.getMessage() +
                        "\n부분 저장된 파일이 있다면 삭제하세요."));
            } finally {
                busy.set(false);
                runOnUiThread(() -> downloadButton.setEnabled(!qualities.isEmpty()));
            }
        });
    }

    private void showStatus(String message) {
        status.setText(message);
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        worker.shutdownNow();
        webView.destroy();
        super.onDestroy();
    }
}
